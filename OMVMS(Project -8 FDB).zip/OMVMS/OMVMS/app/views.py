from django.shortcuts import render , get_object_or_404, redirect
from .models import Product , Customer , ShoppingCart
from django.contrib import messages
from django.db import IntegrityError
from django.http import HttpResponseServerError


def home(request):
    customer_name = request.session.get('customer_name', None)
    if 'is_authenticated' in request.session and request.session['is_authenticated'] == True:
        products = Product.objects.all()
        return render(request, 'app/home.html', {'products': products, 'customer_name': customer_name})
    else:
        return redirect("login")


def product_detail_view(request, product_id):
    product = get_object_or_404(Product, pk=product_id)

    context = list(range(product.quantity))
    if request.method == 'POST':
        # Get or create the customer
        customer_name = request.session.get('customer_name', None)
        customer, created = Customer.objects.get_or_create(customer_name=customer_name)

        # Get the selected quantity from the form
        selected_quantity = int(request.POST.get('quantity', 1))

        # Get or create the shopping cart
        shopping_cart, created = ShoppingCart.objects.get_or_create(customer=customer, product=product)

        # Update the quantity or set it to the selected quantity
        shopping_cart.quantity = selected_quantity
        shopping_cart.save()
        messages.success(request, f'{product.product_name} added to cart.')

    return render(request, 'app/product_detail.html', {'product': product, 'quantity_range': context})

def view_cart(request):
    customer_name = request.session.get('customer_name', None)
    if 'is_authenticated' in request.session and request.session['is_authenticated'] == True:
        customer = get_object_or_404(Customer, customer_name=customer_name)
        cart_items = ShoppingCart.objects.filter(customer=customer)
        total_price = sum(item.product.price * item.quantity for item in cart_items)
        return render(request, 'app/cart.html', {'cart_items': cart_items, 'total_price': total_price})
    else:
        return redirect("login")

def checkout_view(request):
    # delete from ShoppingCart model
    customer_name = request.session.get('customer_name', None)
    customer = get_object_or_404(Customer, customer_name=customer_name)
    cart_items = ShoppingCart.objects.filter(customer=customer)
    cart_items.delete()

    return render(request, 'app/checkout.html')

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Use customer model to check if email and password is present in customer model
        customer = Customer.objects.filter(customer_email=email, password=password).first()  # Update with actual customer details

        if customer is not None:
            # Authentication successful
            request.session['customer_id'] = customer.customer_id  # Store the customer ID in the session
            request.session['customer_name'] = customer.customer_name  # Store the customer name in the session
            request.session['is_authenticated'] = True  # Set is_authenticated flag to True
            return home(request) 
        else:
            # Authentication failed
            messages.error(request, 'Invalid credentials. Please try again.')

    return render(request, 'app/login.html')

def signup_view(request):
    if request.method == 'POST':
        # Extract data from the form
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            # Try to create a new customer
            new_customer, created = Customer.objects.get_or_create(
                customer_email=email,
                defaults={'customer_name': name, 'password': password}
            )

            if created:
                messages.success(request, 'User successfully created')
            else:
                # User with this email already exists
                messages.error(request, 'User with this email already exists. Please use a different email.')

        except IntegrityError as e:
            # Handle integrity error (duplicate entry)
            messages.error(request, 'Error creating user. Please try again.')

            # print or log the actual IntegrityError for debugging
            print(f'IntegrityError: {e}')

            # Return an HTTP 500 response (server error) or redirect to an error page
            return HttpResponseServerError('Error creating user. Please try again later.')

    return render(request, 'app/signup.html')

def logout_view(request):
    # Clear the session data
    request.session.flush()
    return redirect('login')

